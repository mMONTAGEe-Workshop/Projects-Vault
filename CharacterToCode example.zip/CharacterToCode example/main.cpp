#include <iostream>

using namespace std;

int main() {
    char D = 'D';
    char A = 'A';
    char V = 'V';
    char I = 'I';
    char S = 'S';
    char E = 'E';
    char R = 'R';
    char J = 'J';
    char L = 'L';
    char H = 'H';
    char O = 'O';

    int x = 0;
    int y = 0;
    int z = 0;
    int m = 0;
    int a = 0;
    int b = 0;
    int c = 0;
    int d = 0;
    int e = 0;
    int f = 0;
    int g = 0;


    x = D;
    y = A;
    z = V;
    m = I;

    a = S;
    b = E;
    c = R;
    d = J;

    e = L;
    f = H;
    g = O;

    cout<<"D="<<x<<" "<<"A="<<y<<" "<<"V="<<z<<" "<<"I="<<m<<" "<<"D="<<x<<endl;
    cout<<"S="<<a<<" "<<"E="<<b<<" "<<"R="<<c<<" "<<"J="<<d<<endl;
    cout<<"V="<<z<<" "<<"L="<<e<<" "<<"A="<<y<<" "<<"D="<<x<<endl;
    cout<<"H="<<f<<" "<<"O="<<g<<" "<<"V="<<y<<" "<<"O="<<f<<endl;
}